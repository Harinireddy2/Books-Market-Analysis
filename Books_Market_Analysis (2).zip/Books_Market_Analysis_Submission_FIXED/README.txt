BOOKS MARKET ANALYSIS – SUBMISSION

1. Jupyter Notebook – Books_Market_Analysis_FINAL.ipynb
2. Scraped Dataset – scraped_books.csv
3. Cleaned Dataset – cleaned_books.csv
4. Visualizations – Visualizations folder
5. Business Questions with Answers – Business_Questions_with_Answers.txt
6. Business Insights – Business_Insights.txt
7. Recommendations – Recommendations.txt

The notebook contains the live Requests + BeautifulSoup multi-page scraper and the complete cleaning/EDA workflow. The included CSV files are 20-row preview files prepared in this environment; they are not fabricated 1,000-row data.
